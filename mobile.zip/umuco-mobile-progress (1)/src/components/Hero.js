// Ported from web src/components/Hero.jsx.
// The rotating stacked-cards visual (absolute-positioned divs cycling via
// setInterval) is kept, laid out with RN's absolute positioning instead of
// Tailwind translate/scale classes. Same rotation logic, same 3 features,
// same stats and quest-progress rows, same copy.
import React, { useState, useEffect } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { ArrowRight, Compass, BookOpen, Users } from 'lucide-react-native';
import { useLanguage } from '../contexts/LanguageContext';
import { UmucoGlyph } from './UmucoGlyphs';
import { colors, fontFamily } from '../theme/colors';

import cardImg1 from '../assets/hero/tradi.jpg';
import cardImg2 from '../assets/hero/book.png';
import cardImg3 from '../assets/hero/iraba.jpg';

function Hero({ onNavigate, onExploreMore }) {
  const [order, setOrder] = useState([0, 1, 2]);
  const { t } = useLanguage();

  useEffect(() => {
    const interval = setInterval(() => {
      setOrder((prevOrder) => {
        const nextOrder = [...prevOrder];
        const last = nextOrder.pop();
        nextOrder.unshift(last);
        return nextOrder;
      });
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const stats = [
    { value: '200+', label: t('hero.stats.oralStories') },
    { value: '3', label: t('hero.stats.languageModules') },
    { value: '24/7', label: t('hero.stats.aiAssistant') },
  ];

  const questSteps = [
    { step: '01', label: t('landing.quest.pick') },
    { step: '02', label: t('landing.quest.learn') },
    { step: '03', label: t('landing.quest.earn') },
  ];

  const features = [
    { title: t('hero.feature1.title'), desc: t('hero.feature1.desc'), img: cardImg3, Icon: Users },
    { title: t('hero.feature2.title'), desc: t('hero.feature2.desc'), img: cardImg2, Icon: BookOpen },
    { title: t('hero.feature3.title'), desc: t('hero.feature3.desc'), img: cardImg1, Icon: Compass },
  ];

  // translate/scale/z-index equivalents of the web "positions" stack
  const stackStyles = [
    { top: 0, left: 0, zIndex: 10, transform: [{ scale: 0.9 }] },
    { top: 10, left: 10, zIndex: 20, transform: [{ scale: 0.95 }] },
    { top: 20, left: 20, zIndex: 30, transform: [{ scale: 1 }] },
  ];

  return (
    <View style={styles.section}>
      <View style={styles.pill}>
        <UmucoGlyph type="trail" size={18} />
        <Text style={styles.pillText}>{t('hero.tagline')}</Text>
      </View>

      <Text style={styles.title}>
        {t('hero.title1')}{'\n'}
        <Text style={styles.titleAccent}>{t('hero.title2')}</Text>
      </Text>

      <Text style={styles.description}>{t('hero.description')}</Text>

      <View style={styles.ctaRow}>
        <TouchableOpacity style={styles.primaryButton} onPress={() => onNavigate('signup')}>
          <Text style={styles.primaryButtonText}>{t('hero.getInvolved')}</Text>
          <ArrowRight size={16} color={colors.ivory} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.secondaryButton} onPress={onExploreMore}>
          <Text style={styles.secondaryButtonText}>{t('hero.exploreMore')}</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.statsGrid}>
        {stats.map((stat, index) => (
          <View key={index} style={styles.statCard}>
            <Text style={styles.statValue}>{stat.value}</Text>
            <Text style={styles.statLabel}>{stat.label}</Text>
          </View>
        ))}
      </View>

      <View style={styles.questProgress}>
        {questSteps.map((item) => (
          <View key={item.step} style={styles.questStep}>
            <Text style={styles.questStepNumber}>{item.step}</Text>
            <Text style={styles.questStepLabel}>{item.label}</Text>
          </View>
        ))}
      </View>

      <View style={styles.stackWrap}>
        <View style={styles.stack}>
          {features.map((item, index) => {
            const { Icon } = item;
            const assignedPositionIndex = order[index];
            return (
              <View key={index} style={[styles.card, stackStyles[assignedPositionIndex]]}>
                <Image source={item.img} style={styles.cardImage} />
                <View style={styles.cardOverlay} />
                <View style={styles.cardTextWrap}>
                  <View style={styles.cardTitleRow}>
                    <Icon size={16} color={colors.peach} />
                    <Text style={styles.cardTitle}>{item.title}</Text>
                  </View>
                  <Text style={styles.cardDesc} numberOfLines={2}>{item.desc}</Text>
                </View>
              </View>
            );
          })}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  section: { width: '100%', backgroundColor: colors.ivory, paddingHorizontal: 20, paddingTop: 24, paddingBottom: 24 },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(252,223,211,0.3)',
    borderWidth: 1,
    borderColor: colors.cream,
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 6,
    marginBottom: 16,
  },
  pillText: { fontSize: 12, fontFamily: fontFamily.sansSemiBold, color: colors.brown },
  title: { fontSize: 32, fontFamily: fontFamily.sansBold, color: colors.espresso, lineHeight: 38, marginBottom: 16 },
  titleAccent: { color: colors.brown },
  description: { fontSize: 14, fontFamily: fontFamily.sans, color: colors.taupe, lineHeight: 22, marginBottom: 24 },
  ctaRow: {
    flexDirection: 'row',
    gap: 10,
    paddingBottom: 24,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(234,219,200,0.6)',
    marginBottom: 24,
  },
  primaryButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: colors.brown,
    borderRadius: 10,
    paddingVertical: 14,
  },
  primaryButtonText: { fontSize: 13, fontFamily: fontFamily.sansSemiBold, color: colors.ivory },
  secondaryButton: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(141,73,58,0.4)',
    borderRadius: 10,
    paddingVertical: 14,
  },
  secondaryButtonText: { fontSize: 13, fontFamily: fontFamily.sansSemiBold, color: colors.brown },
  statsGrid: { flexDirection: 'row', gap: 12, marginBottom: 20 },
  statCard: { flex: 1, alignItems: 'flex-start' },
  statValue: { fontSize: 20, fontFamily: fontFamily.sansBold, color: colors.brown },
  statLabel: { fontSize: 11, fontFamily: fontFamily.sansMedium, color: colors.taupe, marginTop: 2 },
  questProgress: { flexDirection: 'row', gap: 16, marginBottom: 24 },
  questStep: { flex: 1 },
  questStepNumber: { fontSize: 11, fontFamily: fontFamily.sansBold, color: colors.sand },
  questStepLabel: { fontSize: 12, fontFamily: fontFamily.sansSemiBold, color: colors.espresso, marginTop: 2 },
  stackWrap: { alignItems: 'center', height: 260, marginTop: 8 },
  stack: { width: 220, height: 240, position: 'relative' },
  card: {
    position: 'absolute',
    width: 180,
    height: 220,
    borderRadius: 4,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(234,219,200,0.6)',
    backgroundColor: '#171717',
  },
  cardImage: { ...StyleSheet.absoluteFillObject, width: undefined, height: undefined, resizeMode: 'cover' },
  cardOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.55)' },
  cardTextWrap: { position: 'absolute', left: 14, right: 14, bottom: 14 },
  cardTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 },
  cardTitle: { fontSize: 13, fontFamily: fontFamily.sansBold, color: colors.white },
  cardDesc: { fontSize: 10, fontFamily: fontFamily.sans, color: 'rgba(229,229,229,0.9)', lineHeight: 14 },
});

export default Hero;
